﻿using koll2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace koll2.Services
{
    public class RepoService : IRepoService
    {
        private readonly RepositoryContext _repository;
        public RepoService(RepositoryContext repository)
        {
            _repository = repository;
        }
        public IQueryable<Album> GetAlbumById(int id)
        {
            return _repository.
        }
    }
}
