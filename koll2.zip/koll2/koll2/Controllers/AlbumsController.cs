﻿using koll2.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace koll2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AlbumsController : ControllerBase
    {
        private readonly IRepoService _service;

        public ClientsController(IRepoService service)
        {
            _service = service;
        }

        [HttpGet]
        public async Task<IActionResult> Get(int albumId)
        {
            return Ok(
                await _service.GetAllOrders()
                .Select(e =>
                new ZamowienieGet
                {
                    IdZamowienia = e.IdZamowienia,
                    DataPrzyjecia = e.DataPrzyjecia,
                    DataRealizacji = e.DataRealizacji,
                    Uwagi = e.Uwagi,
                    Wyroby = e.ZamowieniaWyrobCukierniczy.Select(e => new Wyroby
                    {
                        IdWyrobu = e.IdWyrobuCukierniczego,
                        Nazwa = e.WyrobCukierniczy.Nazwa,
                        Ilosc = e.Ilosc,
                        Uwagi = e.Uwagi,
                        Typ = e.WyrobCukierniczy.Typ,
                        CenaZaSztuke = e.WyrobCukierniczy.CenaZaSzt
                    }).ToList()
                }).ToListAsync()
            );
        }
    }
}
